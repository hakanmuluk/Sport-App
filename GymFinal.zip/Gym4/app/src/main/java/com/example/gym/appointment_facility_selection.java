package com.example.gym;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class appointment_facility_selection extends AppCompatActivity {
    private String bilkentid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_facility_selection);
        bilkentid = getIntent().getStringExtra("bilkentid");
    }

    public void openMainCampusActivity(View v){
        Intent i = new Intent(this, selection_of_sports.class);
        i.putExtra("Chooser", "main");
        i.putExtra("bilkentid", bilkentid);
        startActivity(i);

    }

    public void openDormintoryActivity(View v){
        Intent i = new Intent(this, selection_of_sports.class);
        i.putExtra("Chooser", "dorm");
        i.putExtra("bilkentid", bilkentid);
        startActivity(i);

    }

    public void openEastCampusActivity(View v){
        Intent i = new Intent(this, selection_of_sports.class);
        i.putExtra("Chooser", "east");
        i.putExtra("bilkentid", bilkentid);
        startActivity(i);

    }


}
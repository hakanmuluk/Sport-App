package com.example.gym;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class selection_of_sports extends AppCompatActivity {

    String facility;
    private String bilkentid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_of_sports);
        Intent i = getIntent();
        facility = i.getStringExtra("Chooser");
        bilkentid = i.getStringExtra("bilkentid");
    }

    //for tennis
    public void openSessionsTennis(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name", "ten");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }

    //for basketball
    public void openSessionsBasket(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name", "bask");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }

    public void openSessionsFitness(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","fit");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }

    public void openSessionsSquash(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","squash");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }

    public void openSessionsSwimming(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","swim");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }

    public void openSessionsFootball(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","foot");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }

    public void openVoleyball(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","vol");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }
    public void openSessionsTableTennis(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","table");
        p.putExtra("bilkentid", bilkentid);
        startActivity(p);


    }
}
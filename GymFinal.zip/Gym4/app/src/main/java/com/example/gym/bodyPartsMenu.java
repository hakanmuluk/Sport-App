package com.example.gym;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class bodyPartsMenu extends AppCompatActivity {

    Button shoulder_button;
    Button abs_button;
    Button chest_button;
    Button back_button;
    Button leg_button;
    Button arm_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_body_parts_menu);

        shoulder_button=findViewById(R.id.shoulder_button);
        abs_button=findViewById(R.id.abs_button);
        chest_button=findViewById(R.id.chest_button);
        back_button=findViewById(R.id.back_button);
        leg_button=findViewById(R.id.leg_button);
        arm_button=findViewById(R.id.arm_button);

        shoulder_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shoulder=new Intent(bodyPartsMenu.this,Shoulder.class);
                startActivity(shoulder);

            }
        });
        abs_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abs=new Intent(bodyPartsMenu.this,Abs.class);
                startActivity(abs);

            }
        });
        chest_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chest=new Intent(bodyPartsMenu.this,Chest.class);
                startActivity(chest);

            }
        });
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back=new Intent(bodyPartsMenu.this,Back.class);
                startActivity(back);

            }
        });
        leg_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent leg=new Intent(bodyPartsMenu.this,Leg.class);
                startActivity(leg);

            }
        });
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back=new Intent(bodyPartsMenu.this,Back.class);
                startActivity(back);

            }
        });
        arm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent arm=new Intent(bodyPartsMenu.this,Arm.class);
                startActivity(arm);

            }
        });

    }
}
package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

public class daysActivity extends AppCompatActivity {
    private User user;
    private fitnessProgram program;
    private RecyclerView rv;
    private TextView textViewDays;
    private TextView textViewDateDays;
    private DaysAdapter adapter;
    private String userUid;
    private FirebaseDatabase database;
    private DatabaseReference reference;
    private ArrayList<fitnessProgram> usersPrograms;
    private String usersProgramsJson;
    private int posOfProgram;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_days);
        userUid = getIntent().getStringExtra("uid");
        posOfProgram = getIntent().getIntExtra("pos", 0);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");
        Query q = reference.orderByChild("firebaseId").equalTo(userUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot d:snapshot.getChildren()){
                    usersProgramsJson = d.child("jSon").getValue(String.class);
                }
                Gson converter = new Gson();
                Type programsType = new TypeToken<ArrayList<fitnessProgram>>(){}.getType();
                usersPrograms = converter.fromJson(usersProgramsJson, programsType);
                program = usersPrograms.get(posOfProgram);
                adapter = new DaysAdapter(daysActivity.this, program.getProgram());
                adapter.setPosOfProgram(posOfProgram);
                adapter.setUserUid(userUid);
                rv.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });





        //program = new fitnessProgram(null, "Bulk");//Firebase
        textViewDays = findViewById(R.id.textViewDays);
        textViewDateDays = findViewById(R.id.textViewDaysDate);
        rv = findViewById(R.id.recyclerViewDays);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_WEEK);

        String dayName = "";
        switch(day){
            case Calendar.MONDAY:
                dayName = "Monday";
                break;
            case Calendar.TUESDAY:
                dayName = "TUESDAY";
                break;
            case Calendar.WEDNESDAY:
                dayName = "WEDNESDAY";
                break;
            case Calendar.THURSDAY:
                dayName = "THURSDAY";
                break;
            case Calendar.FRIDAY:
                dayName = "FRIDAY";
                break;
            case Calendar.SATURDAY:
                dayName = "SATURDAY";
                break;
            case Calendar.SUNDAY:
                dayName = "SUNDAY";
                break;
        }
        textViewDateDays.setText("Today is: " + dayName);












    }
}
package com.example.gym;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BMI extends AppCompatActivity {
    TextView textViewbmicalculator;
    TextView bmi_result;
    EditText edittextheightbmi;
    EditText edittextweightbmi;
    Button bmicalculatebutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
        textViewbmicalculator = findViewById(R.id.textViewbmicalculator);
        bmi_result = findViewById(R.id.bmi_result);
        edittextheightbmi = findViewById(R.id.edittextheightbmi);
        edittextweightbmi = findViewById(R.id.edittextweightbmi);
        bmicalculatebutton = findViewById(R.id.bmicalculatebutton);

        bmicalculatebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double height = Double.parseDouble(edittextheightbmi.getText().toString()) / 100;
                double weight = Double.parseDouble(edittextweightbmi.getText().toString());
                closeKeyboard(edittextheightbmi);
                double bmi = weight / (height * height);
                if(bmi < 18.5){
                    bmi_result.setText("" + bmi + " (underweight)");
                }
                else if(bmi < 25){
                    bmi_result.setText("" + bmi + " (normal)");
                }
                else if(bmi < 30){
                    bmi_result.setText("" + bmi + " (overweight)");
                }
                else {
                    bmi_result.setText("" + bmi + " (obese)");
                }


            }
        });





    }
    private void closeKeyboard(View v){
        View view = v;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

    }
}
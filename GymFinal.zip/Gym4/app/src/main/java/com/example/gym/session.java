package com.example.gym;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class session {
    String sport;
    String faci;
    String time;
    int capacity;
    int remain;
    ArrayList<String> attenders_id;
    String not_id;

    public session(String sport, String faci, String time, int capacity, int remain,ArrayList<String> attenders_id,String not_id) {
        this.sport = sport;
        this.faci = faci;
        this.time = time;
        this.capacity = capacity;
        this.remain = remain;
        this.attenders_id = attenders_id;
        this.not_id = not_id;
    }



    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public String getFaci() {
        return faci;
    }

    public void setFaci(String faci) {
        this.faci = faci;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getRemain() {
        return remain;
    }

    public void setRemain(int remain) {
        this.remain = remain;
    }

    public ArrayList<String> getAttenders_id() {
        return attenders_id;
    }

    public void setAttenders_id(ArrayList<String> attenders_id) {
        this.attenders_id = attenders_id;
    }

    public String getNot_id() {
        return not_id;
    }

    public void setNot_id(String not_id) {
        this.not_id = not_id;
    }

    @NonNull
    @Override
    public String toString() {
        String a="";
        a = getTime() + "/" + getCapacity() + "/" + getRemain();
        return a;
    }
}



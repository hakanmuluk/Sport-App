package com.example.gym;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class session_rv_adapter extends RecyclerView.Adapter<session_rv_adapter.CardViewDesignObjectsHolder> {

    private Context mContext;
    private List<Sesion> sessions_list;
    FirebaseDatabase fd = FirebaseDatabase.getInstance();
    DatabaseReference databasereference = fd.getReference("All_Sessions");
    String key;
    join_session j;
    DatabaseReference baris;
    String bilkentid;

    public void setBilkentid(String bilkentid) {
        this.bilkentid = bilkentid;
    }

    public session_rv_adapter(Context mContext, List<Sesion> sessions_list) {
        this.mContext = mContext;
        this.sessions_list = sessions_list;
    }

    public class CardViewDesignObjectsHolder extends RecyclerView.ViewHolder{

        public TextView variable_hour;
        public TextView variable_capacity;
        public TextView variable_remain;
        public CardView satır_session_card_view;
        public Button join_btn;

        public CardViewDesignObjectsHolder(View view){
            super(view);
            variable_hour = view.findViewById(R.id.variable_hour);
            variable_capacity = view.findViewById(R.id.variable_capacity);
            variable_remain = view.findViewById(R.id.variable_remain);
            satır_session_card_view  = view.findViewById(R.id.satır_session_card_view);
            join_btn = view.findViewById(R.id.join_btn);
        }

    }

    @NonNull
    @Override
    public CardViewDesignObjectsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sessions_card_view,parent,false);
        return new CardViewDesignObjectsHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CardViewDesignObjectsHolder holder, int position) {
        Sesion temp = sessions_list.get(position);
        ArrayList<String> list = temp.getAttenders_id();

        holder.variable_hour.setText(temp.getTime());
        holder.variable_remain.setText(Integer.toString(temp.getRemain()));
        holder.variable_capacity.setText(Integer.toString(temp.getCapacity()));


        j = new join_session();

            holder.join_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    baris = databasereference.child(temp.getFaci()).child(temp.getSport());



                    ArrayList<String> arr_list = temp.getAttenders_id();
                    String a = temp.getNot_id();

                    //String b= j.getIddd();

                    Map<String,Object> bs = new HashMap<>();
                    arr_list.add(bilkentid);

                    bs.put("attenders_id",arr_list);

                    bs.put("remain",temp.getCapacity()-arr_list.size());

                    baris.child(a).updateChildren(bs);

                    holder.join_btn.setEnabled(false);
                    //Toast()

                }

            });

        holder.satır_session_card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "Sport: " + temp.getSport() + " Facility: "+ temp.getFaci(),Toast.LENGTH_LONG).show();
            }
        });



    }

    @Override
    public int getItemCount() {
        return sessions_list.size();
    }



}

package com.example.gym;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

public class User {
    public String name,email;
    public int id_number;
    public String jSon,password, firebaseId;
    public ArrayList<fitnessProgram> programs;
    public String weightsJson;

    public User(String name,String email,int id_number, String jSon, String password){
        this.name=name;
        this.email=email;
        this.id_number=id_number;
        this.password=password;
        this.jSon = jSon;
        firebaseId = "";
        Gson converter = new Gson();
        Type programsType = new TypeToken<ArrayList<fitnessProgram>>(){}.getType();
        programs = converter.fromJson(jSon,programsType);
        //ArrayList<Integer> a = new ArrayList<Integer>();
        ArrayList<HashMap<String, Integer>> a = new ArrayList<HashMap<String, Integer>>();
        weightsJson = converter.toJson(a);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId_number() {
        return id_number;
    }

    public void setId_number(int id_number) {
        this.id_number = id_number;
    }

    public String getjSon() {
        return jSon;
    }

    public void setjSon(String jSon) {
        this.jSon = jSon;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ArrayList<fitnessProgram> getPrograms() {
        return programs;
    }

    public void setPrograms(ArrayList<fitnessProgram> programs) {
        this.programs = programs;
    }
}

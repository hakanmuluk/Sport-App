package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AddExerciseActivity extends AppCompatActivity {
    TextView textViewAddExerciseName;
    TextView textViewAddExerciseSet;
    TextView textViewAddExerciseRep;
    TextView textViewAddExerciseWeight;
    EditText editTextNameAddExercise;
    EditText editTextSetAddExercise;
    EditText editTextRepAddExercise;
    EditText editTextWeightAddEXercise;
    ImageButton addExerciseCheck;
    ImageButton addExerciseCancel;
    ArrayList<fitnessProgram> fitnessPrograms;
    private String usersUid;
    private int posOfProgram;
    private int posOfDay;
    private String usersProgramsJson;
    private FirebaseDatabase database;
    private DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exercise);
        addExerciseCheck = findViewById(R.id.addExercisecheck);
        textViewAddExerciseName = findViewById(R.id.textViewaddExerciseName);
        textViewAddExerciseSet = findViewById(R.id.textViewaddExeciseSet);
        textViewAddExerciseRep = findViewById(R.id.textViewaddExerciseRep);
        textViewAddExerciseWeight = findViewById(R.id.textViewAddExerciseWeight);
        editTextNameAddExercise = findViewById(R.id.editTextNameAddExercise);
        editTextSetAddExercise = findViewById(R.id.editTextSetAddExercise);
        editTextRepAddExercise = findViewById(R.id.editTextRepAddExercise);
        editTextWeightAddEXercise = findViewById(R.id.editTextWeightAddEXercise);

        addExerciseCancel = findViewById(R.id.addExerciseCancel);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");
        usersUid = getIntent().getStringExtra("uid");
        posOfProgram = getIntent().getIntExtra("posOfProgram", 0);
        posOfDay = getIntent().getIntExtra("posOfDay", 0);
        Query q = reference.orderByChild("firebaseId").equalTo(usersUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot d:snapshot.getChildren()){
                    usersProgramsJson = d.child("jSon").getValue(String.class);
                }
                addExerciseCheck.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        System.out.println("aaa");
                        String name = editTextNameAddExercise.getText().toString();
                        int set = Integer.parseInt(editTextSetAddExercise.getText().toString());
                        int rep = Integer.parseInt(editTextRepAddExercise.getText().toString());
                        int weight = Integer.parseInt(editTextWeightAddEXercise.getText().toString());
                        exerciseMoves newExercise = new exerciseMoves(name, rep, set, weight);
                        Gson converter = new Gson();
                        Type programsType = new TypeToken<ArrayList<fitnessProgram>>(){}.getType();
                        fitnessPrograms = converter.fromJson(usersProgramsJson, programsType);
                        fitnessPrograms.get(posOfProgram).getProgram().get(posOfDay).add(newExercise);


                        usersProgramsJson = converter.toJson(fitnessPrograms);
                        Log.e("JSON", usersProgramsJson);
                        Map<String, Object> updateJson = new HashMap<>();
                        updateJson.put("jSon", usersProgramsJson);
                        FirebaseDatabase.getInstance().getReference("Userss").child(usersUid).updateChildren(updateJson);






                        Toast.makeText(AddExerciseActivity.this, "Added", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        addExerciseCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AddExerciseActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                finish();
            }
        });



    }
}
package com.example.gym;

public class exerciseMoves {
    String name;
    int repetition;
    int set;
    int weight;
    //BodyPart bodyPart;
    public exerciseMoves(String name, int repetition, int set, int weight){
        this.name = name;
        this.repetition = repetition;
        this.set = set;
        this.weight = weight;
        //this.bodyPart = bodyPart;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRepetition() {
        return repetition;
    }

    public void setRepetition(int repetition) {
        this.repetition = repetition;
    }

    public int getSet() {
        return set;
    }

    public void setSet(int set) {
        this.set = set;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}

package com.example.gym;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

public class profileeActivity extends AppCompatActivity {
    TextView profileUserName;
    TextView profileUserWeight;
    ImageView imageViewProfile;
    String usersUid;
    FirebaseDatabase database;
    DatabaseReference reference;
    String name;
    String age;
    String weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilee);
        profileUserName = findViewById(R.id.profileUserName);
        profileUserWeight = findViewById(R.id.profileUserWeight);
        //imageViewProfile = findViewById(R.id.imageViewProfile);
        usersUid = getIntent().getStringExtra("uid");
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");
        Query q = reference.orderByChild("firebaseId").equalTo(usersUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot d: snapshot.getChildren()){
                    name = d.child("name").getValue(String.class);
                    weight = d.child("weightsJson").getValue(String.class);
                }
                Gson converter = new Gson();
                Type weightListType = new TypeToken<ArrayList<HashMap<String, Integer>>>() {
                }.getType();
                ArrayList<HashMap<String, Integer>> weightsList = converter.fromJson(weight, weightListType);
                profileUserName.setText(name);
                String date = "";
                for(String key:weightsList.get(weightsList.size() - 1).keySet()){
                    date = key;
                }
                profileUserWeight.setText("" + weightsList.get(weightsList.size() - 1).get(date) + "kg");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}
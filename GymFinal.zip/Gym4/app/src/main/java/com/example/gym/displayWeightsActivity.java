package com.example.gym;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

public class displayWeightsActivity extends AppCompatActivity {
    private ArrayList<HashMap<String, Integer>> datesAndWeights;
    private RecyclerView rv;
    private displayWeightsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_weights);
        String jSon = getIntent().getStringExtra("datesAndWeights");
        Gson converter = new Gson();
        Type programsType = new TypeToken<ArrayList<HashMap<String, Integer>>>() {
        }.getType();
        datesAndWeights = converter.fromJson(jSon,programsType);
        rv = findViewById(R.id.displayWeightsActivity);
        adapter = new displayWeightsAdapter(displayWeightsActivity.this, datesAndWeights);
        rv.setAdapter(adapter);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));






    }
}
package com.example.gym;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class programAdapter extends RecyclerView.Adapter<programAdapter.programCardObjectsHolder>{
    private Context mconcept;
    private ArrayList<fitnessProgram> fitnessPrograms;
    private String userUid;
    private TextView numberOfPrograms;
//Constructor
    public programAdapter(Context mconcept, ArrayList<fitnessProgram> fitnessPrograms) {
        this.mconcept = mconcept;
        this.fitnessPrograms = fitnessPrograms;
    }
    public class programCardObjectsHolder extends RecyclerView.ViewHolder{
        CardView programCard;
        ImageView programCardImage;
        TextView programCardTextView;

        public programCardObjectsHolder(View view){
            super(view);
            programCard = view.findViewById(R.id.programCard);
            programCardImage = view.findViewById(R.id.programCardImage);
            programCardTextView = view.findViewById(R.id.programCardTextView);
        }

    }
    @NonNull
    @Override
    public programCardObjectsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.program_cardview, parent, false);


        return new programCardObjectsHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull programCardObjectsHolder holder, int position) {
        int pos = holder.getAdapterPosition();
        String programName = fitnessPrograms.get(position).getProgramName();
        holder.programCardTextView.setText(programName);
        holder.programCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToDays = new Intent(mconcept, daysActivity.class);
                goToDays.putExtra("uid", userUid);
                goToDays.putExtra("pos", pos);

                //goToDays.putExtra("PosOfProgram", pos);
                mconcept.startActivity(goToDays);
                ((Activity)mconcept).finish();
            }
        });

    }

    @Override
    public int getItemCount() {

        return fitnessPrograms.size();
    }

    public void setNumberOfPrograms(TextView numberOfPrograms) {
        this.numberOfPrograms = numberOfPrograms;
    }

    public void deleteProgram(int i){
        fitnessPrograms.remove(i);
        notifyItemRemoved(i);
        numberOfPrograms.setText("You have " + fitnessPrograms.size() + " programs");
        Gson converter = new Gson();
        String jSon = converter.toJson(fitnessPrograms);
        Map<String, Object> updateJson = new HashMap<>();
        updateJson.put("jSon", jSon);
        FirebaseDatabase.getInstance().getReference("Userss").child(userUid).updateChildren(updateJson);



        //notifyDataSetChanged();
    }
    public void setUserUid(String s){
        userUid = s;
    }


}

package com.example.gym;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class menu extends AppCompatActivity {
    public String usersUid;
    public Button buttonGoWeight;
    public Button goVideos;
    public Button goBmi;
    private FirebaseDatabase database;
    private DatabaseReference reference;
    private String bilkentId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");
        usersUid = getIntent().getStringExtra("uid");
        buttonGoWeight = findViewById(R.id.buttonGoWeight);
        goBmi = findViewById(R.id.goBmi);
        goVideos = findViewById(R.id.menuVideos);

        Query q = reference.orderByChild("firebaseId").equalTo(usersUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot d:snapshot.getChildren()){
                    int idd = d.child("id_number").getValue(Integer.class);
                    bilkentId = "" + idd;

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        buttonGoWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menu.this, ActivityAddWeight.class);
                i.putExtra("uid", usersUid);
                startActivity(i);

            }
        });
        goBmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menu.this, BMI.class);
                startActivity(i);
            }
        });
        goVideos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goVideos = new Intent(menu.this, bodyPartsMenu.class);
                startActivity(goVideos);
            }
        });

    }

    public void openAppointment(View v){
        Intent i = new Intent(this,appointment_facility_selection.class);
        i.putExtra("bilkentid", bilkentId);
        startActivity(i);
    }

    public void openFitnessProgram(View v){
        Intent i = new Intent(this,ProgramsActivity.class);
        i.putExtra("uid", usersUid);
        startActivity(i);
    }

    public void openProfile(View v){
        Intent i = new Intent(this,profileeActivity.class);
        i.putExtra("uid", usersUid);
        startActivity(i);
        //finish();
    }



}
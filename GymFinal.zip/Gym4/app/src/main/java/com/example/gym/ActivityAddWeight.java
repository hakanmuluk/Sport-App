package com.example.gym;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ActivityAddWeight extends AppCompatActivity {
    private TextView textViewAddWeight;
    private EditText editTextAddWeight;
    private Button buttonSaveWeight;
    private Button buttonGoChart;
    private String usersUid;
    private String weightJson;
    private ArrayList<HashMap<String, Integer>> weightList;
    private FirebaseDatabase database;
    private DatabaseReference reference;
    private boolean firstChangeHappened;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);
        firstChangeHappened = false;
        textViewAddWeight = findViewById(R.id.textViewAddWeight);
        editTextAddWeight = findViewById(R.id.editTextAddWeight);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonGoChart = findViewById(R.id.buttonGoChart);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");
        usersUid = getIntent().getStringExtra("uid");
        Query q = reference.orderByChild("firebaseId").equalTo(usersUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!firstChangeHappened) {
                    for (DataSnapshot d : snapshot.getChildren()) {
                        weightJson = d.child("weightsJson").getValue(String.class);
                    }
                    Gson converter = new Gson();
                    Type programsType = new TypeToken<ArrayList<HashMap<String, Integer>>>() {
                    }.getType();
                    weightList = converter.fromJson(weightJson, programsType);
                    if(weightList == null){
                        weightList = new ArrayList<HashMap<String, Integer>>();
                    }
                    buttonSaveWeight.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            int newWeight = Integer.parseInt(editTextAddWeight.getText().toString());
                            closeKeyboard(editTextAddWeight);
                            editTextAddWeight.getText().clear();
                            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                            Date date = new Date();
                            String dateOfWeight = formatter.format(date);
                            HashMap<String, Integer> b = new HashMap<String, Integer>();
                            b.put(dateOfWeight, newWeight);
                            weightList.add(b);
                            weightJson = converter.toJson(weightList);
                            Map<String, Object> updateWeight = new HashMap<>();
                            updateWeight.put("weightsJson", weightJson);
                            Log.e("uid", usersUid);
                            reference.child(usersUid).updateChildren(updateWeight);
                        }
                    });


                    firstChangeHappened = true;
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        buttonGoChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ActivityAddWeight.this, displayWeightsActivity.class);
                i.putExtra("datesAndWeights",weightJson);
                startActivity(i);
                //finish();
            }
        });


    }
    private void closeKeyboard(View v){
        View view = v;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

    }
}
package com.example.gym;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AddHeightAgeWeight extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_height_age_weight);
    }
}
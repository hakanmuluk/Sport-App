package com.example.gym;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;

public class displayWeightsAdapter extends RecyclerView.Adapter<displayWeightsAdapter.weightsAdapterHolder> {
    private Context mContext;
    private ArrayList<HashMap<String,Integer>> list;

    public displayWeightsAdapter(Context mContext, ArrayList<HashMap<String, Integer>> list) {
        this.mContext = mContext;
        this.list = list;
    }
    public class weightsAdapterHolder extends RecyclerView.ViewHolder{
        CardView card;
        TextView date;
        TextView weight;


        public weightsAdapterHolder(View view){
            super(view);
            card = view.findViewById(R.id.cardViewWeights);
            date = view.findViewById(R.id.weightDateCard);
            weight = view.findViewById(R.id.weightCardWeight);
        }
    }

    @NonNull
    @Override
    public weightsAdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.weights_cardview, parent, false);

        return new weightsAdapterHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull weightsAdapterHolder holder, int position) {
        int pos = holder.getAdapterPosition();
        String date = "";
        for(String key:list.get(pos).keySet()){
            date = key;
        }
        String weight = "" + list.get(pos).get(date);
        holder.date.setText(date);
        holder.weight.setText(weight + " kg");



    }

    @Override
    public int getItemCount() {
        return list.size();
    }


}

package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class viewSportsActivity extends AppCompatActivity {
    ArrayList<exerciseMoves> exercises;
    RecyclerView rv;
    ImageButton imageButtonAdd;
    ArrayList<fitnessProgram> fitnessPrograms;
    private String usersUid;
    private int posOfProgram;
    private int posOfDay;
    private String usersProgramsJson;
    private FirebaseDatabase database;
    private DatabaseReference reference;
    private sportAdapter adapter;
    private boolean firstChangeHappened;
    private int exercizesSize;
    private ArrayList<exerciseMoves> exercisesNew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_sports);
        rv = findViewById(R.id.viewSportRv);
        rv.setHasFixedSize(true);
        firstChangeHappened = false;

        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");
        usersUid = getIntent().getStringExtra("uid");
        posOfProgram = getIntent().getIntExtra("posOfProgram", 0);
        posOfDay = getIntent().getIntExtra("posOfDay", 0);
        Query q = reference.orderByChild("firebaseId").equalTo(usersUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for (DataSnapshot d : snapshot.getChildren()) {
                        usersProgramsJson = d.child("jSon").getValue(String.class);
                    }
                    Gson converter = new Gson();
                    Type programsType = new TypeToken<ArrayList<fitnessProgram>>() {
                    }.getType();
                    fitnessPrograms = converter.fromJson(usersProgramsJson, programsType);
                    exercisesNew = fitnessPrograms.get(posOfProgram).getProgram().get(posOfDay);


                    if(!firstChangeHappened){
                        //exercises = (ArrayList<exerciseMoves>) fitnessPrograms.get(posOfProgram).getProgram().get(posOfDay).clone();
                        exercises = fitnessPrograms.get(posOfProgram).getProgram().get(posOfDay);
                        exercizesSize = exercises.size();
                    }
                    if(exercises.size() < exercisesNew.size()){

                        exercises.add(exercisesNew.get(exercisesNew.size() - 1));
                        adapter.notifyItemInserted(exercises.size() - 1);

                        exercizesSize = exercises.size();
                    }

                    if(!firstChangeHappened) {
                        adapter = new sportAdapter(viewSportsActivity.this, exercises);
                        adapter.setUserUid(usersUid);
                        adapter.setPrograms(fitnessPrograms);
                        adapter.setPosOfProgram(posOfProgram);
                        adapter.setPosOfDay(posOfDay);
                        rv.setAdapter(adapter);
                        rv.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));
                        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeSport(adapter));
                        itemTouchHelper.attachToRecyclerView(rv);
                        firstChangeHappened = true;
                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });











        /*exercises = new ArrayList<exerciseMoves>();
        exercises.add(new exerciseMoves("Leg Press", 12, 3, 60));
        exercises.add(new exerciseMoves("Squat", 15, 3, 80));*/

        imageButtonAdd = findViewById(R.id.imageButtonaddSport);
        imageButtonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToAddExercise = new Intent(viewSportsActivity.this, AddExerciseActivity.class);
                goToAddExercise.putExtra("uid", usersUid);
                goToAddExercise.putExtra("posOfProgram", posOfProgram);
                goToAddExercise.putExtra("posOfDay", posOfDay);
                viewSportsActivity.this.startActivity(goToAddExercise);
            }
        });


    }
}